
	/*
	 * Class Salad
	 *author : Victoria Reyderman
	 *created: 11/20/2019
	 */

	public final class Salad extends MenuItem {

	    public Salad (String name, String description, int calories, double price){
	    	super(name, description, calories, price);
	    }
	}
