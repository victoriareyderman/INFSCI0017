
public class Checking extends Account implements IAccount {

	   public Checking(int accountNumber, double initBalance) {
	       super(accountNumber, initBalance);
	   }

	   public void withdraw(double amount) {

	       setBalance(getBalance() - amount);
	   }

	   public void deposit(double amount) {

	       setBalance(amount + getBalance());
	   }

	   public int getAccountNumber() {

	       return super.getAccountNumber();
	   }

	   public double getBalance() {

	       return super.getBalance();
	   }

	}