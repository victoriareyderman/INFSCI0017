
public class Savings extends Account implements IAccount {

   public Savings(int accountNumber, double initBalance) {
       super(accountNumber, initBalance);

   }
   public void withdraw(double amount) {

       if (amount > getBalance())
           setBalance(getBalance() - amount - 5); // 5 dollar penalty for withdrawal deducted from balance
       else {

           System.out.println("Insufficient Balance. Overdrafts not allowed.");
       }
   }
   public void deposit(double amount) {
       if (amount > 0) {
           setBalance(getBalance() + amount);
       }
       if (getBalance() > 1000) {
           setBalance(getBalance() + 5);  //bonus
       }
   }

   public int getAccountNumber() {

       return super.getAccountNumber();
   }
   public double getBalance() {

       return super.getBalance();
   }

}