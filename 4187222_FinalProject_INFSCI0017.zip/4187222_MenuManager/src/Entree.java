
	/*
	 * Class Entree
	 * author : Victoria Reyderman
	 * created: 11/20/2019
	 */

	public final class Entree extends MenuItem  {

	    public Entree (String name, String description, int calories, double price){
	    	super(name, description, calories, price);
	     // remove other methods because of super class <-- subclass
	    }


	}