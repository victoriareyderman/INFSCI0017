

/*
 * Class Side
 *author: Victoria Reyderman
 *created: 11/20/2019
 */

public final class Side extends MenuItem {

	public Side (String name, String description, int calories, double price){
		super(name, description, calories, price);
	//removed other methods because of superclass
	}

}