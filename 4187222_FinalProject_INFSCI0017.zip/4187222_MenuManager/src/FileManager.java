/*
 * Class File Manager!!

 * author: Victoria Reyderman

 * created: 11/20/2019  

 */
import java.util.*;
import java.io.*;

public class FileManager {
	public static ArrayList<MenuItem> readItems(String dishes) {
		ArrayList<String> list = new ArrayList<String>();
		ArrayList<MenuItem> menuItems=new ArrayList<MenuItem>();
		String s=null;
		try {
			FileReader freader=new FileReader(dishes);
			BufferedReader breader=new BufferedReader(freader);
			
			while((s=breader.readLine())!=null) {
				list.add(s);
			}
			for(String line : list){
				String [] res = line.split("@@");
				if(res[1].equals("dessert")) {
					Dessert dessert=new Dessert(res[0],res[2],Integer.valueOf(res[3]),Double.valueOf(res[4]));
					menuItems.add(dessert);
				}else if(res[1].equals("entree")) {
					Entree entree=new Entree(res[0],res[2],Integer.valueOf(res[3]),Double.valueOf(res[4]));
					menuItems.add(entree);
				}else if(res[1].equals("salad")) {
					Salad salad=new Salad(res[0],res[2],Integer.valueOf(res[3]),Double.valueOf(res[4]));
					menuItems.add(salad);
				}else if(res[1].equals("side")) {
					Side side=new Side(res[0],res[2],Integer.valueOf(res[3]),Double.valueOf(res[4]));
					menuItems.add(side);
				}
			}
			breader.close();
			freader.close();
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
		return menuItems;
	}
	/* method
	 * to write menu
	 * + catch if error to avoid crash
	 */

	public static void writeMenus(String dishes, ArrayList<Menu> menus) {
		try {
			FileWriter fwriter = new FileWriter(dishes);
			BufferedWriter bwriter = new BufferedWriter(fwriter);
			for (int i = 0; i < menus.size(); i++) {
				bwriter.write(menus.get(i).description()+"\n"+
						"Total calories: "+menus.get(i).totalCalories()+"\n"+
						"Total price: "+menus.get(i).totalPrice()+"\n");
				bwriter.newLine();
			}
			bwriter.close();
			fwriter.close();
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
