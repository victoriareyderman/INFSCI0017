
public class MenuTest {
	/*

	 * Class MenuTester
	 * author: Victoria Reyderman
	 * created: 11/20/19

	 */
	public static void main(String[] args){
		MenuManager randomize = new MenuManager("dishes.txt");
		Menu myMenu = randomize.randomMenu(null);
		System.out.println(myMenu.description()+"\nTotal calories"+
							myMenu.totalCalories());
	}
}
