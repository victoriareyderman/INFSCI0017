

/*
 *Class Dessert
 *author : Victoria Reyderman
 *created: 11/20/2019
 */

public final class Dessert extends MenuItem {

	public Dessert (String name, String description, int calories, double price){
		super(name, description, calories, price);
		//removed other methods because of super class
	}

}