package edu.pitt.is17.lab5;
// Victoria Reyderman

import java.util.Random;
import java.util.Scanner;

public class RollDice
{
 
	public static void main(String[] args)
	{
		Random rand=new Random();
		Scanner scan= new Scanner(System.in);

		while(true)
		{
			System.out.print("Enter number of rolls:");
			int rolls=scan.nextInt();

			RollDice(rolls, rand);
			System.out.print("Continue? Yes(y) or No(n)?");


			Scanner scan1=new Scanner(System.in);
			String scanchar=scan1.nextLine();

			if(scanchar.equalsIgnoreCase("y"))
			{
				continue;
			}
			else if(scanchar.equalsIgnoreCase("n"))
			{
				break;
			}
		}
	}

	public static void RollDice(int number,Random rand)
	{
		int random1;
		int random2;
		int counter2=0;
		int counter3=0;
		int counter4=0;
		int counter5=0;
		int counter6=0;
		int counter7=0;
		int counter8=0;
		int counter9=0;
		int counter10=0;
		int counter11=0;
		int counter12=0;

		for(int i=0;i<number;i++)
		{
			random1=rand.nextInt(6)+1;
			random2=rand.nextInt(6)+1;

			switch (random1+random2)
			{

			case 2:
				counter2++;
				break;

			case 3:
				counter3++;
				break;

			case 4:
				counter4++;
				break;

			case 5:
				counter5++;
				break;

			case 6:
				counter6++;
				break;

			case 7:
				counter7++;
				break;

			case 8:
				counter8++;
				break;

			case 9:
				counter9++;
				break;
				
			case 10:
				counter10++;
				break;

			case 11:
				counter11++;
				break;

			case 12:
				counter12++;
				break;
			}
		}

		System.out.println("Number of times 2 occurred:"+counter2+" and its fraction="+counter2+"/"+number);
		System.out.println("Number of times 3 occurred:"+counter3+" and its fraction="+counter3+"/"+number);
		System.out.println("Number of times 4 occurred:"+counter4+" and its fraction="+counter4+"/"+number);
		System.out.println("Number of times 5 occurred:"+counter5+" and its fraction="+counter5+"/"+number);
		System.out.println("Number of times 6 occurred:"+counter6+" and its fraction="+counter6+"/"+number);
		System.out.println("Number of times 7 occurred:"+counter7+" and its fraction="+counter7+"/"+number);
		System.out.println("Number of times 8 occurred:"+counter8+" and its fraction="+counter8+"/"+number);
		System.out.println("Number of times 9 occurred:"+counter9+" and its fraction="+counter9+"/"+number);
		System.out.println("Number of times 10 occurred:"+counter10+" and its fraction="+counter10+"/"+number);
		System.out.println("Number of times 11 occurred:"+counter11+" and its fraction="+counter11+"/"+number);
		System.out.println("Number of times 12 occurred:"+counter12+" and its fraction="+counter12+"/"+number);
  }
}
