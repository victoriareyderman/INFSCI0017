package edu.pitt.lab12;

public class Task2 {


void printArrayElements(int a[], int size){
    if(size == 1){
        System.out.println(a[size-1]);
    }
    else{
        printArrayElements(a,size-1);
        System.out.println(a[size-1]);
    }
}
