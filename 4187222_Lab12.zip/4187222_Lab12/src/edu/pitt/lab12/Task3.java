package edu.pitt.lab12;

import java.util.Arrays;

import java.util.Scanner;


public class Task3 {

		public static void main(String[] args)

		{

			Scanner scan = new Scanner(System.in);
			int size;
			System.out.print("Enter size of array: ");

			size = scan.nextInt();
			int[] a = new int[size];
			for(int i=0;i<size;i++){
				System.out.print("Enter element "+(i+1)+":");

				a[i] = scan.nextInt();

			}

			int k;
			System.out.print("Enter value of K: ");
			k = scan.nextInt();
			Arrays.sort(a);

			System.out.println("Combination is as below");
			printCombos(a, "", 0,size, k);

		}

		public static void printCombos(int[] a, String out, int i, int n, int k)

		{
			if (k > n) {
				return;
			}

			if (k == 0) {
				System.out.println(out);
				return;

			}
			for (int j = i; j < n; j++)

			{
				printCombos(a, out + " " + (a[j]) , j + 1, n, k - 1);
				while (j < n - 1 && a[j] == a[j + 1]) {
					j++;

				}

			}

		}

	}

