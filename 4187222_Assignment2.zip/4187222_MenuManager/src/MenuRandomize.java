/*
 * Class MenuRandomize
 * author: Victoria Reyderman
 * created: 11/05/2019
 */
import java.util.ArrayList;


public class MenuRandomize {
	private ArrayList<Entree> entrees = new ArrayList<Entree>();
	private ArrayList<Side> sides = new ArrayList<Side>();
	private ArrayList<Salad> salads = new ArrayList<Salad>();
	private ArrayList<Dessert> desserts = new ArrayList<Dessert>();
	//

	public MenuRandomize (String entreeFile, String sideFile, String saladFile, String dessertFile){
		entrees = FileManager.readEntrees(entreeFile);
		sides = FileManager.readSides(sideFile);
		salads = FileManager.readSalads(saladFile);
		desserts = FileManager.readDesserts(dessertFile);
	}

	public Menu randomMenu() {

		Menu randomMenu = new Menu ("Random Menu:");

		randomMenu.setEntree(entrees.get( (int) (entrees.size() * Math.random() )));

		randomMenu.setSide(sides.get((int)(sides.size()*Math.random())));
		randomMenu.setSalad(salads.get((int)(salads.size()*Math.random())));
		randomMenu.setDessert(desserts.get((int)(desserts.size()*Math.random())));

		return randomMenu;
	}

}