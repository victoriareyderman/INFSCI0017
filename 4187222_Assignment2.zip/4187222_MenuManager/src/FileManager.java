/*
 * Class File Manager

 * author: Victoria Reyderman

 * created: 11/05/2019  

 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class FileManager {

	final static String SPLIT = "@@";   

	public static ArrayList<Entree> readEntrees (String entrees){


		ArrayList<Entree> entree = new ArrayList<Entree>();   
		int arrayIndex=0;  

		try {
			FileReader fr = new FileReader(entrees);
			BufferedReader reader = new BufferedReader(new FileReader(entrees));
			String line;
			while ((line = reader.readLine()) != null) {
				
				int first = line.indexOf(SPLIT);   
				int second = line.indexOf(SPLIT, first + 1);


				entree.add(arrayIndex,                                    
						new Entree(line.substring(0,first),                  
								line.substring(first+2,second),                    
								Integer.parseInt(line.substring(second+2)),0));       
				arrayIndex++;  
			}
			reader.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return entree;
	}

	public static ArrayList<Side> readSides (String sides){
		ArrayList<Side> side = new ArrayList<Side>();
		int arrayIndex = 0 ;
		try {
			FileReader fr = new FileReader(sides);
			BufferedReader reader = new BufferedReader(new FileReader(sides));
			String line;
			
			
			while ((line = reader.readLine()) != null) {
				int first = line.indexOf(SPLIT);
				int second = line.indexOf(SPLIT, first + 1);
				side.add(arrayIndex, new Side(line.substring(0,first), line.substring(first+2,second), Integer.parseInt(line.substring(second+2)),0));
				arrayIndex++;
			}
			reader.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return side;
	}

	public static ArrayList<Salad> readSalads (String salads){
		ArrayList<Salad> salad = new ArrayList<Salad>();
		int arrayIndex = 0 ;
		try {
			FileReader fr = new FileReader(salads);
			BufferedReader reader = new BufferedReader(new FileReader(salads));
			String line = null;
			while ((line = reader.readLine()) != null) {
				int first = line.indexOf(SPLIT);
				int second = line.indexOf(SPLIT, first + 1);
				salad.add(arrayIndex, new Salad(line.substring(0,first), line.substring(first+2,second), Integer.parseInt(line.substring(second+2)),0));
				arrayIndex++;
			}
			reader.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return salad;
	}


	public static ArrayList<Dessert> readDesserts (String dessert){
		ArrayList<Dessert> desserts = new ArrayList<Dessert>();
		int arrayIndex = 0 ;
		try {
			FileReader fr = new FileReader(dessert);
			BufferedReader reader = new BufferedReader(new FileReader(dessert));
			String line;
			
			
			while ((line = reader.readLine()) != null) {
				int first = line.indexOf(SPLIT);
				int second = line.indexOf(SPLIT, first + 1);
				desserts.add(arrayIndex, new Dessert(line.substring(0,first), line.substring(first+2,second), Integer.parseInt(line.substring(second+2)),0 ));
				arrayIndex++;
			}
			reader.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return desserts;
	}

}