
public class MenuTest {

	/*

	 * Class MenuTester

	 * author: Victoria Reyderman

	 * created: 10/08/19

	 */


	public static void main(String[] args) throws Exception{

		Entree firstEntreee = new Entree("FirstEntree", "Sirloin Steak. A delicious piece of 1/2 a pound of our carefully selected meat grilled and seasoned. Choose how much you want it cooked.", 300);

		Entree secondEntreee = new Entree("SecondEntree", "Zucchini Pesto with Grilled Chicken. Zucchini noodles with basil pesto and garlic,cream, grilled chicken, mushrooms, tomato and parmesan.", 440);

		Salad firstSalad = new Salad("FirstSaladOne", "Greek Salad. Salad topped with sliced cucumbers, onion, feta cheese, and olives. Seasoned with salt and Greek mountain oregano, and dressed with olive oil. ",300);

		Side firstSide = new Side("FirstSideOne", "Half Caesar Salad. Topped with croutons and parmesan cheese.", 175);

		Side secondSide = new Side("SecondSideOne", "Sweet Potatoe Fries. Waffle Cut.", 200);

		Dessert firstDessert = new Dessert("FirstDessertOne", "Chocolate Lava Cake. Lava Cake with Fudge Chocolate topped with vanilla ice cream.", 600);
		
		

		Menu firstMenu = new Menu("First Menu:",firstEntreee,secondSide);

		System.out.println(firstMenu.name);

		System.out.println("Total Calories:" +firstMenu.totalCalories());

		System.out.println(firstMenu.description());



		Menu secondMenu = new Menu("Second Menu:",secondEntreee,firstSide,firstSalad,firstDessert);

		System.out.println(secondMenu.name);

		System.out.println("Total Calories:" +secondMenu.totalCalories());


		System.out.println(secondMenu.description());

	}

}

