
public class Menu {

	/*

	 * Class Menu

	 * author: Victoria Reyderman

	 * created: 11/05/19

	 */

	public String name;

	public Salad salad;
	
	public Side side;

	public Entree entree;


	public Dessert dessert;



	Menu(String name){

		this.name= name;

		this.entree=null;

		this.side=null;

		this.salad=null;

		this.dessert=null;

	}



	Menu(String name, Entree entree, Side side){

		this.name=name;

		this.entree=entree;

		this.side=side;

		this.salad=null;

		this.dessert=null;

	}



	Menu(String name, Entree entree, Side side, Salad salad, Dessert dessert){

		this.name=name;

		this.entree=entree;

		this.side=side;

		this.salad=salad;

		this.dessert=dessert;

	}



	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public Salad getSalad() {

		return salad;

	}

	public void setSalad(Salad salad) {

		this.salad = salad;

	}

	public Entree getEntree() {

		return entree;

	}

	public void setEntree(Entree entree) {

		this.entree = entree;

	}

	public Side getSide() {

		return side;

	}

	public void setSide(Side side) {

		this.side = side;

	}

	public Dessert getDessert() {

		return dessert;

	}

	public void setDessert(Dessert dessert) {

		this.dessert = dessert;

	}

	int totalCalories() {


		return (salad!=null?salad.getCalories():0)+ (entree!=null?entree.getCalories():0)+(side!=null?side.getCalories():0)+(dessert!=null?dessert.getCalories():0);

	}



	String description() {

		String s = "Salad: " + (salad!=null? salad.getDescription():"N/A")+"\n" +

"Entree: "+ (entree!=null? entree.getDescription():"N/A")+"\n" +

"Side: "+(side!=null? side.getDescription() : "N/A")+ "\n"

+ "Dessert: " + (dessert!=null ? dessert.getDescription():"N/A") + "\n";

		return s;  

	}

}

